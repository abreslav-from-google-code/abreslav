rm *.zip; zip rotate_the_world.zip * -x *.exe *.png *.dcu
zip rotate_the_world.zip DelphiGraph.dcu
