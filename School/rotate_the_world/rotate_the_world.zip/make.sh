rm *.dcu; rm *.zip; zip rotate_the_world.zip * -x *.exe *.png
